﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace x360ce.App
{
	public enum CloudState
	{
		None = 0,
		Busy = 1,
		Done = 2,
	}
}
