﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace x360ce.App.Forms
{
	public partial class HardwareForm : Form
	{
		public HardwareForm()
		{
			InitializeComponent();
		}
	}
}
