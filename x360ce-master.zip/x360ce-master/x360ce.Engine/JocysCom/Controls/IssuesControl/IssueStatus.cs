﻿namespace JocysCom.ClassLibrary.Controls.IssuesControl
{
    public enum IssueStatus
    {
        Idle = 0,
        Checking,
        Fixing,
    }
}
