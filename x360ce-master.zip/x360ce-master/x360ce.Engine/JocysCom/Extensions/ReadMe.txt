﻿You mus add "using" or "Import" to the page in order to use these extensions.

using JocysCom.ClassLibrary.Extensions;

