﻿namespace JocysCom.WebSites.Engine.Security
{
	public enum UserQueryName
	{
		None = 0,
		Qt,
		All,
		ByRole,
	}
}
