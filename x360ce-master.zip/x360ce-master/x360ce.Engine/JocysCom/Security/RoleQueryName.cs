﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JocysCom.WebSites.Engine.Security
{
	public enum RoleQueryName
	{
		None = 0,
		Qt,
		All,
		ByUser,
	}
}
