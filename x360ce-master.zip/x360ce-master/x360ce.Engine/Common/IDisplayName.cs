﻿namespace x360ce.Engine
{
	public interface IDisplayName
	{
		string DisplayName { get; }

		bool IsEnabled { get; }

	}
}
