﻿namespace x360ce.Engine
{
	public enum DPadEnum
	{
		Up = 0,
		Right = 9000,
		Down = 18000,
		Left = 27000,
	}
}
