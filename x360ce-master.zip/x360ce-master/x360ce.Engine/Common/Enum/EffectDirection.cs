﻿namespace x360ce.Engine
{
    public enum ForceEffectDirection : int
    {
        NoDirection = 0,
        Positive = 1,
        Negative = -1,
    }
}
